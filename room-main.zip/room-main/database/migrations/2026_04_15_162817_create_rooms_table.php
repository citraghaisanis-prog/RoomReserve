<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('rooms', function (Blueprint $table) {
        $table->id();
        $table->string('name'); 
        $table->integer('capacity'); 
        $table->string('type'); 
        $table->boolean('is_active')->default(true); 
        $table->timestamps();
    });
}
};
